# PageVault: OpenShelf Challenge

A campus-wide peer-to-peer textbook exchange web application enabling university students to list textbooks, search by academic course code, manage borrow requests (Pending → Approved → Returned), track automated 7-day return countdowns, receive wishlist alerts, rate peer reliability, and coordinate campus handoffs.

## Features Implemented
- **Book Listing & Cataloging**: List textbooks with title, author, edition, course code, condition, and availability toggle. Includes Open Library ISBN lookup and simulated barcode scanner auto-fill.
- **Course-Aware Book Search**: Real-time filtering by course code (e.g., `CS301`, `CS201`), title, author, department, and availability status.
- **3-State Borrow Workflow**: Atomic status transitions (`Available` -> `Pending` -> `Borrowed` -> `Returned`) preventing double-borrow conflicts.
- **Automated Due-Date Reminders**: Dynamic client-side due-date engine computing remaining days/hours for 7-day return windows, plus simulated overdue/upcoming alerts and browser notification triggers.
- **My Books & Borrowing History Dashboard**: Separates listed books, incoming approval queues, active borrowings with countdown timers, and historical exchanges.
- **Stretch Features**:
  - **ISBN Barcode Scanner & Open Library API Lookup**
  - **Peer Trust & Reliability Rating (1–5 stars)**
  - **Lender-Borrower Campus Handoff Chat**
  - **Campus Department Wishlist Alerts**

## Project Structure
```
pagevault-openshelf/
├── client/                  # React + Vite + Tailwind CSS Frontend
│   ├── index.html
│   ├── package.json
│   ├── postcss.config.js
│   ├── tailwind.config.js
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx
│       ├── index.css
│       ├── App.jsx
│       └── data/
│           └── textbooks.js # 35 seeded engineering & science textbooks
├── server/                  # Node.js + Express + JSON/SQLite-ready Backend
│   ├── package.json
│   ├── server.js
│   └── data/
│       └── db.json
└── README.md
```

## Quick Start

### 1. Run the Frontend (React + Vite)
```bash
cd client
npm install
npm run dev
```

### 2. Run the Backend API (Express)
```bash
cd server
npm install
npm start
```
