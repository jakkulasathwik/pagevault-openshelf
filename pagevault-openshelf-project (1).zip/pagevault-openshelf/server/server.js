import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, 'data', 'db.json');

const app = express();
app.use(cors());
app.use(express.json());

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

function readDb() {
  return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
}

function writeDb(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// GET all books with optional courseCode or status query
app.get('/api/books', (req, res) => {
  const db = readDb();
  const { q, status } = req.query;
  let books = db.books;
  if (q) {
    const query = q.toLowerCase();
    books = books.filter(
      (b) =>
        b.courseCode.toLowerCase().includes(query) ||
        b.title.toLowerCase().includes(query) ||
        b.department.toLowerCase().includes(query)
    );
  }
  if (status && status !== 'All') {
    books = books.filter((b) => b.status === status);
  }
  res.json(books);
});

// POST create a new book listing
app.post('/api/books', (req, res) => {
  const db = readDb();
  const newBook = {
    id: `bk-${Date.now()}`,
    status: 'Available',
    ...req.body,
    courseCode: (req.body.courseCode || '').toUpperCase()
  };
  db.books.unshift(newBook);
  writeDb(db);
  res.status(201).json(newBook);
});

// POST atomic borrow request (Available -> Reserved)
app.post('/api/requests', (req, res) => {
  const db = readDb();
  const { bookId, borrowerId } = req.body;
  const book = db.books.find((b) => b.id === bookId);
  if (!book || book.status !== 'Available') {
    return res.status(409).json({ error: 'Book is no longer available.' });
  }
  book.status = 'Reserved';
  const borrowReq = {
    id: `req-${Date.now()}`,
    bookId: book.id,
    bookTitle: book.title,
    courseCode: book.courseCode,
    lenderId: book.ownerId,
    borrowerId,
    status: 'Pending',
    requestedAt: Date.now(),
    dueDate: null
  };
  db.requests.unshift(borrowReq);
  writeDb(db);
  res.status(201).json(borrowReq);
});

// PATCH approve or return request
app.patch('/api/requests/:id', (req, res) => {
  const db = readDb();
  const borrowReq = db.requests.find((r) => r.id === req.params.id);
  if (!borrowReq) return res.status(404).json({ error: 'Request not found' });

  const book = db.books.find((b) => b.id === borrowReq.bookId);
  const { action } = req.body;

  if (action === 'approve') {
    borrowReq.status = 'Approved';
    borrowReq.approvedAt = Date.now();
    borrowReq.dueDate = Date.now() + SEVEN_DAYS_MS;
    if (book) book.status = 'Borrowed';
  } else if (action === 'return') {
    borrowReq.status = 'Returned';
    borrowReq.returnedAt = Date.now();
    if (book) book.status = 'Available';
  } else if (action === 'reject') {
    borrowReq.status = 'Rejected';
    if (book) book.status = 'Available';
  }

  writeDb(db);
  res.json(borrowReq);
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`PageVault OpenShelf API running on http://localhost:${PORT}`);
});
