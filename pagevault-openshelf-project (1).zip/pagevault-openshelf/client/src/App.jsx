import React, { useState, useEffect, useMemo } from 'react';
import {
  BookOpen,
  Search,
  PlusCircle,
  Bell,
  Clock,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Star,
  MessageSquare,
  Heart,
  QrCode,
  ShieldCheck,
  UserCheck,
  Sparkles,
  AlertTriangle,
  Send,
  Calendar,
  Tag
} from 'lucide-react';
import { INITIAL_STUDENTS, SEED_TEXTBOOKS } from './data/textbooks';

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

export default function App() {
  const [students, setStudents] = useState(INITIAL_STUDENTS);
  const [currentUserId, setCurrentUserId] = useState('stu-2');
  const [books, setBooks] = useState(SEED_TEXTBOOKS);
  const [requests, setRequests] = useState([]);
  const [wishlistCourses, setWishlistCourses] = useState(['CS301', 'DS301']);
  const [notifications, setNotifications] = useState([
    {
      id: 'notif-welcome',
      type: 'info',
      title: 'Welcome to PageVault OpenShelf',
      message: 'Switch personas in the top bar to test listing, requesting, approving, and returning textbooks.',
      timestamp: Date.now()
    }
  ]);

  const [activeTab, setActiveTab] = useState('catalog'); // catalog | dashboard | wishlist
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');

  // Modals
  const [showListModal, setShowListModal] = useState(false);
  const [activeChatRequest, setActiveChatRequest] = useState(null);
  const [chatInput, setChatInput] = useState('');
  const [ratingModal, setRatingModal] = useState(null);
  const [ratingScore, setRatingScore] = useState(5);
  const [nowTick, setNowTick] = useState(Date.now());

  // New Book Form State
  const [newBook, setNewBook] = useState({
    title: '',
    author: '',
    edition: '1st Ed.',
    isbn: '',
    courseCode: '',
    department: 'Computer Science',
    condition: 'Like New'
  });
  const [isbnLoading, setIsbnLoading] = useState(false);
  const [scannerSimulated, setScannerSimulated] = useState(false);

  // Live clock tick for dynamic countdowns
  useEffect(() => {
    const timer = setInterval(() => setNowTick(Date.now()), 30000);
    return () => clearInterval(timer);
  }, []);

  const currentUser = useMemo(
    () => students.find((s) => s.id === currentUserId) || students[0],
    [students, currentUserId]
  );

  const departments = useMemo(
    () => ['All', ...Array.from(new Set(books.map((b) => b.department)))],
    [books]
  );

  const pushNotification = (type, title, message) => {
    setNotifications((prev) => [
      { id: `notif-${Date.now()}-${Math.random()}`, type, title, message, timestamp: Date.now() },
      ...prev.slice(0, 14)
    ]);
  };

  // Filtered Catalog
  const filteredBooks = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return books.filter((b) => {
      const matchesQuery =
        !q ||
        b.courseCode.toLowerCase().includes(q) ||
        b.title.toLowerCase().includes(q) ||
        b.author.toLowerCase().includes(q) ||
        b.department.toLowerCase().includes(q) ||
        b.isbn.includes(q);
      const matchesDept = selectedDept === 'All' || b.department === selectedDept;
      const matchesStatus = statusFilter === 'All' || b.status === statusFilter;
      return matchesQuery && matchesDept && matchesStatus;
    });
  }, [books, searchQuery, selectedDept, statusFilter]);

  // Open Library ISBN Auto-Fill
  const handleIsbnLookup = async (isbnCode) => {
    const cleanIsbn = (isbnCode || newBook.isbn).replace(/[^0-9X]/gi, '');
    if (!cleanIsbn) return;
    setIsbnLoading(true);
    try {
      const res = await fetch(`https://openlibrary.org/api/books?bibkeys=ISBN:${cleanIsbn}&format=json&jscmd=data`);
      const data = await res.json();
      const entry = data[`ISBN:${cleanIsbn}`];
      if (entry) {
        setNewBook((prev) => ({
          ...prev,
          isbn: cleanIsbn,
          title: entry.title || prev.title,
          author: entry.authors ? entry.authors.map((a) => a.name).join(', ') : prev.author
        }));
        pushNotification('success', 'Open Library Metadata Loaded', `Populated details for ISBN ${cleanIsbn}.`);
      } else {
        pushNotification('warning', 'ISBN Not Found Online', 'Enter title and author manually or try another ISBN.');
      }
    } catch {
      pushNotification('warning', 'Offline Lookup Mode', 'Could not reach Open Library API; manual entry enabled.');
    } finally {
      setIsbnLoading(false);
    }
  };

  const simulateBarcodeScan = () => {
    setScannerSimulated(true);
    const sampleIsbn = '9780262033848';
    setTimeout(() => {
      setNewBook((prev) => ({
        ...prev,
        isbn: sampleIsbn,
        title: 'Introduction to Algorithms (Scanned Copy)',
        author: 'Thomas H. Cormen, Charles E. Leiserson',
        edition: '3rd Ed.',
        courseCode: prev.courseCode || 'CS201'
      }));
      setScannerSimulated(false);
      pushNotification('success', 'Barcode Scanned via Camera', `Captured ISBN ${sampleIsbn} and auto-filled book metadata.`);
    }, 900);
  };

  // List a New Book
  const handleCreateBook = (e) => {
    e.preventDefault();
    if (!newBook.title.trim() || !newBook.courseCode.trim()) return;
    const normalizedCourse = newBook.courseCode.trim().toUpperCase();
    const created = {
      id: `bk-${Date.now()}`,
      title: newBook.title.trim(),
      author: newBook.author.trim() || 'University Press',
      edition: newBook.edition.trim() || '1st Ed.',
      isbn: newBook.isbn.trim() || '9780000000000',
      courseCode: normalizedCourse,
      department: newBook.department,
      condition: newBook.condition,
      status: 'Available',
      ownerId: currentUser.id,
      color: 'from-indigo-600 to-purple-700'
    };

    setBooks((prev) => [created, ...prev]);
    setShowListModal(false);
    setNewBook({
      title: '',
      author: '',
      edition: '1st Ed.',
      isbn: '',
      courseCode: '',
      department: 'Computer Science',
      condition: 'Like New'
    });

    if (wishlistCourses.includes(normalizedCourse)) {
      pushNotification(
        'alert',
        `Wishlist Match: ${normalizedCourse}`,
        `"${created.title}" was just listed on campus!`
      );
    } else {
      pushNotification('success', 'Book Listed', `"${created.title}" (${normalizedCourse}) is now live in the catalog.`);
    }
  };

  // Atomic Borrow Request (prevents double-borrow race conditions)
  const handleRequestBorrow = (book) => {
    if (book.status !== 'Available' || book.ownerId === currentUser.id) return;

    // Flip status atomically to Reserved (Pending approval)
    setBooks((prev) =>
      prev.map((b) => (b.id === book.id && b.status === 'Available' ? { ...b, status: 'Reserved' } : b))
    );

    const newReq = {
      id: `req-${Date.now()}`,
      bookId: book.id,
      bookTitle: book.title,
      courseCode: book.courseCode,
      lenderId: book.ownerId,
      borrowerId: currentUser.id,
      status: 'Pending', // Pending | Approved | Returned | Rejected
      requestedAt: Date.now(),
      approvedAt: null,
      dueDate: null,
      returnedAt: null,
      ratedByBorrower: false,
      messages: [
        {
          id: 'm-1',
          senderId: currentUser.id,
          text: `Hi! Could I borrow "${book.title}" for ${book.courseCode}? Happy to meet at the Main Library lobby.`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]
    };

    setRequests((prev) => [newReq, ...prev]);
    pushNotification(
      'info',
      'Borrow Request Sent',
      `Requested "${book.title}" (${book.courseCode}). Status flipped to Reserved pending lender approval.`
    );
  };

  // Lender Approves Request -> Starts 7-Day Countdown
  const handleApproveRequest = (req) => {
    const now = Date.now();
    const due = now + SEVEN_DAYS_MS;

    setRequests((prev) =>
      prev.map((r) =>
        r.id === req.id ? { ...r, status: 'Approved', approvedAt: now, dueDate: due } : r
      )
    );
    setBooks((prev) =>
      prev.map((b) => (b.id === req.bookId ? { ...b, status: 'Borrowed' } : b))
    );

    pushNotification(
      'success',
      'Exchange Approved — 7-Day Timer Active',
      `"${req.bookTitle}" is now marked Borrowed. Automated return reminder set for 7 days.`
    );
  };

  // Lender Rejects Request -> Releases Book Back to Available
  const handleRejectRequest = (req) => {
    setRequests((prev) =>
      prev.map((r) => (r.id === req.id ? { ...r, status: 'Rejected' } : r))
    );
    setBooks((prev) =>
      prev.map((b) => (b.id === req.bookId ? { ...b, status: 'Available' } : b))
    );
    pushNotification('warning', 'Request Declined', `"${req.bookTitle}" has been returned to Available status.`);
  };

  // Return Book -> Completes Workflow & Prompts Peer Rating
  const handleReturnBook = (req) => {
    setRequests((prev) =>
      prev.map((r) =>
        r.id === req.id ? { ...r, status: 'Returned', returnedAt: Date.now() } : r
      )
    );
    setBooks((prev) =>
      prev.map((b) => (b.id === req.bookId ? { ...b, status: 'Available' } : b))
    );
    pushNotification(
      'success',
      'Book Returned to OpenShelf',
      `"${req.bookTitle}" (${req.courseCode}) is back in Available circulation!`
    );
    if (req.borrowerId === currentUser.id) {
      setRatingModal(req);
      setRatingScore(5);
    }
  };

  // Simulate Fast-Forward Time for Demoing Due-Date Reminders
  const simulateNearDueDate = (req, hoursRemaining) => {
    const newDue = Date.now() + hoursRemaining * 60 * 60 * 1000;
    setRequests((prev) =>
      prev.map((r) => (r.id === req.id ? { ...r, dueDate: newDue } : r))
    );
    const label = hoursRemaining < 0 ? 'OVERDUE' : `Due in ${hoursRemaining}h`;
    pushNotification(
      'alert',
      `Automated Return Reminder (${label})`,
      `Action required: "${req.bookTitle}" (${req.courseCode}) return deadline alert triggered!`
    );
  };

  const toggleBookAvailability = (book) => {
    if (book.status === 'Borrowed' || book.status === 'Reserved') return;
    setBooks((prev) =>
      prev.map((b) =>
        b.id === book.id
          ? { ...b, status: b.status === 'Available' ? 'Unavailable' : 'Available' }
          : b
      )
    );
  };

  const submitPeerRating = () => {
    if (!ratingModal) return;
    setStudents((prev) =>
      prev.map((s) => {
        if (s.id !== ratingModal.lenderId) return s;
        const total = s.rating * s.reviewsCount + ratingScore;
        const count = s.reviewsCount + 1;
        return { ...s, rating: Number((total / count).toFixed(2)), reviewsCount: count };
      })
    );
    setRequests((prev) =>
      prev.map((r) => (r.id === ratingModal.id ? { ...r, ratedByBorrower: true } : r))
    );
    pushNotification('success', 'Peer Reliability Rating Submitted', `Rated exchange ${ratingScore}/5 stars.`);
    setRatingModal(null);
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!chatInput.trim() || !activeChatRequest) return;
    const msg = {
      id: `m-${Date.now()}`,
      senderId: currentUser.id,
      text: chatInput.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setRequests((prev) =>
      prev.map((r) =>
        r.id === activeChatRequest.id ? { ...r, messages: [...r.messages, msg] } : r
      )
    );
    setActiveChatRequest((prev) => ({ ...prev, messages: [...prev.messages, msg] }));
    setChatInput('');
  };

  const getCountdownBadge = (dueDate) => {
    if (!dueDate) return null;
    const diffMs = dueDate - nowTick;
    const hours = Math.round(diffMs / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    if (diffMs < 0) {
      return {
        label: `Overdue by ${Math.abs(hours)}h`,
        style: 'bg-rose-100 text-rose-800 border-rose-300',
        urgent: true
      };
    }
    if (hours <= 24) {
      return {
        label: `Due in ${hours}h — Return Soon`,
        style: 'bg-amber-100 text-amber-800 border-amber-300',
        urgent: true
      };
    }
    return {
      label: `${days}d ${hours % 24}h left (7-day limit)`,
      style: 'bg-emerald-100 text-emerald-800 border-emerald-300',
      urgent: false
    };
  };

  const myListedBooks = books.filter((b) => b.ownerId === currentUser.id);
  const incomingRequests = requests.filter((r) => r.lenderId === currentUser.id && r.status !== 'Rejected');
  const myBorrowings = requests.filter((r) => r.borrowerId === currentUser.id);
  const activeUrgentAlerts = myBorrowings.filter(
    (r) => r.status === 'Approved' && r.dueDate && r.dueDate - nowTick <= 24 * 60 * 60 * 1000
  );

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Top Navigation */}
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-sm">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight text-slate-900">PageVault</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                  OpenShelf
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">Campus Peer-to-Peer Textbook Exchange</p>
            </div>
          </div>

          {/* Demo Persona Switcher */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200">
              <UserCheck className="w-4 h-4 text-indigo-600" />
              <span className="text-xs font-medium text-slate-600 hidden md:inline">Acting as:</span>
              <select
                value={currentUserId}
                onChange={(e) => setCurrentUserId(e.target.value)}
                className="bg-transparent text-xs font-semibold text-slate-900 focus:outline-none cursor-pointer"
              >
                {students.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.department.split(' ')[0]}) ★ {s.rating}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={() => setShowListModal(true)}
              className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold px-4 py-2 rounded-xl shadow-sm transition"
            >
              <PlusCircle className="w-4 h-4" />
              <span>List a Book</span>
            </button>
          </div>
        </div>

        {/* Sub-Nav Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between border-t border-slate-100 bg-slate-50/70">
          <nav className="flex gap-1 py-2">
            {[
              { id: 'catalog', label: 'Course Catalog', count: books.length },
              {
                id: 'dashboard',
                label: 'My Exchanges & Books',
                count: incomingRequests.filter((r) => r.status === 'Pending').length + myBorrowings.filter((r) => r.status === 'Approved').length
              },
              { id: 'wishlist', label: 'Department Wishlist', count: wishlistCourses.length }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium transition flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
                }`}
              >
                <span>{tab.label}</span>
                <span className="text-xs px-1.5 py-0.5 rounded-full bg-slate-200/70 text-slate-700">
                  {tab.count}
                </span>
              </button>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Verified Campus ID: {currentUser.contact}</span>
          </div>
        </div>
      </header>

      {/* Automated Urgent Return Reminder Banner */}
      {activeUrgentAlerts.length > 0 && (
        <div className="bg-amber-50 border-b border-amber-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 text-amber-900 text-sm">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
              <span>
                <strong>Automated Return Reminder:</strong> You have {activeUrgentAlerts.length} borrowed textbook(s) due within 24 hours or overdue ({activeUrgentAlerts.map((a) => a.courseCode).join(', ')}).
              </span>
            </div>
            <button
              onClick={() => setActiveTab('dashboard')}
              className="text-xs font-semibold bg-amber-600 text-white px-3 py-1.5 rounded-lg hover:bg-amber-700"
            >
              Manage Returns
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Live Notification Strip */}
        {notifications.length > 0 && (
          <div className="mb-6 bg-white border border-slate-200 rounded-2xl p-3.5 shadow-sm flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                <Bell className="w-4 h-4" />
              </div>
              <div className="truncate">
                <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 mr-2">
                  {notifications[0].title}
                </span>
                <span className="text-sm text-slate-700">{notifications[0].message}</span>
              </div>
            </div>
            <span className="text-xs text-slate-400 shrink-0">Live Feed</span>
          </div>
        )}

        {/* TAB 1: COURSE-AWARE CATALOG */}
        {activeTab === 'catalog' && (
          <div>
            {/* Search & Filter Controls */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm mb-6 grid grid-cols-1 md:grid-cols-12 gap-3">
              <div className="md:col-span-6 relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by course code (e.g. CS301, EE201), title, author, or ISBN..."
                  className="w-full pl-10 pr-4 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="md:col-span-3">
                <select
                  value={selectedDept}
                  onChange={(e) => setSelectedDept(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  {departments.map((d) => (
                    <option key={d} value={d}>
                      {d === 'All' ? 'All Departments' : d}
                    </option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-3">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="All">All Statuses</option>
                  <option value="Available">Available Only</option>
                  <option value="Reserved">Reserved (Pending)</option>
                  <option value="Borrowed">Borrowed</option>
                </select>
              </div>
            </div>

            {/* Book Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {filteredBooks.map((book) => {
                const owner = students.find((s) => s.id === book.ownerId) || students[0];
                const isMine = book.ownerId === currentUser.id;
                const badgeStyles = {
                  Available: 'bg-emerald-100 text-emerald-800 border-emerald-200',
                  Reserved: 'bg-amber-100 text-amber-800 border-amber-200',
                  Borrowed: 'bg-rose-100 text-rose-800 border-rose-200',
                  Unavailable: 'bg-slate-200 text-slate-700 border-slate-300'
                };

                return (
                  <div
                    key={book.id}
                    className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition overflow-hidden flex flex-col"
                  >
                    {/* Dynamic SVG-style Cover Fallback with Course Code */}
                    <div className={`h-36 bg-gradient-to-br ${book.color} p-4 text-white flex flex-col justify-between relative`}>
                      <div className="flex items-center justify-between">
                        <span className="px-2.5 py-1 rounded-lg bg-black/30 backdrop-blur-sm text-xs font-bold tracking-wide">
                          {book.courseCode}
                        </span>
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${badgeStyles[book.status]}`}>
                          {book.status}
                        </span>
                      </div>
                      <div>
                        <p className="text-[11px] uppercase tracking-wider text-white/80">{book.department}</p>
                        <h3 className="font-bold text-base leading-snug line-clamp-2">{book.title}</h3>
                      </div>
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div className="space-y-2">
                        <p className="text-xs text-slate-600 line-clamp-1">{book.author}</p>
                        <div className="flex items-center gap-2 text-xs text-slate-500">
                          <span className="px-2 py-0.5 bg-slate-100 rounded-md font-medium">{book.edition}</span>
                          <span className="px-2 py-0.5 bg-slate-100 rounded-md font-medium">Cond: {book.condition}</span>
                        </div>

                        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                          <span className="text-slate-600 font-medium">
                            {isMine ? 'Listed by You' : owner.name}
                          </span>
                          <span className="inline-flex items-center gap-1 text-amber-600 font-semibold">
                            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            {owner.rating} ({owner.reviewsCount})
                          </span>
                        </div>
                      </div>

                      <div className="mt-4">
                        {isMine ? (
                          <button
                            onClick={() => toggleBookAvailability(book)}
                            disabled={book.status === 'Borrowed' || book.status === 'Reserved'}
                            className="w-full py-2 px-3 rounded-xl text-xs font-semibold border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 disabled:opacity-50"
                          >
                            {book.status === 'Available'
                              ? 'Pause Listing'
                              : book.status === 'Unavailable'
                              ? 'Mark Available'
                              : `Currently ${book.status}`}
                          </button>
                        ) : (
                          <button
                            onClick={() => handleRequestBorrow(book)}
                            disabled={book.status !== 'Available'}
                            className={`w-full py-2 px-3 rounded-xl text-xs font-semibold transition ${
                              book.status === 'Available'
                                ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-sm'
                                : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                            }`}
                          >
                            {book.status === 'Available' ? 'Request Borrow (7 Days)' : `Unavailable (${book.status})`}
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: MY BOOKS & BORROWING HISTORY DASHBOARD */}
        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Column: Borrowed Books & Return Countdowns */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-indigo-600" />
                  <span>My Borrowed Textbooks ({myBorrowings.length})</span>
                </h2>
              </div>

              {myBorrowings.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-sm text-slate-500">
                  You haven&apos;t requested any textbooks yet. Browse the Course Catalog to borrow one!
                </div>
              ) : (
                myBorrowings.map((req) => {
                  const lender = students.find((s) => s.id === req.lenderId) || students[0];
                  const countdown = req.status === 'Approved' ? getCountdownBadge(req.dueDate) : null;

                  return (
                    <div key={req.id} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="text-xs font-bold text-indigo-600">{req.courseCode}</span>
                          <h3 className="font-bold text-slate-900">{req.bookTitle}</h3>
                          <p className="text-xs text-slate-500">Lender: {lender.name} ({lender.handle})</p>
                        </div>
                        <span
                          className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                            req.status === 'Approved'
                              ? 'bg-indigo-100 text-indigo-800'
                              : req.status === 'Pending'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {req.status}
                        </span>
                      </div>

                      {countdown && (
                        <div className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center justify-between ${countdown.style}`}>
                          <span className="flex items-center gap-1.5">
                            <Calendar className="w-4 h-4" />
                            {countdown.label}
                          </span>
                          <div className="flex gap-1.5">
                            <button
                              onClick={() => simulateNearDueDate(req, 6)}
                              className="underline hover:opacity-80"
                              title="Simulate 6 hours remaining"
                            >
                              Sim 6h Left
                            </button>
                            <span>·</span>
                            <button
                              onClick={() => simulateNearDueDate(req, -3)}
                              className="underline hover:opacity-80"
                              title="Simulate overdue state"
                            >
                              Sim Overdue
                            </button>
                          </div>
                        </div>
                      )}

                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <button
                          onClick={() => setActiveChatRequest(req)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Handoff Chat ({req.messages.length})</span>
                        </button>

                        {req.status === 'Approved' && (
                          <button
                            onClick={() => handleReturnBook(req)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>Mark Returned</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Right Column: Incoming Requests & My Listed Books */}
            <div className="space-y-6">
              <div className="space-y-3">
                <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>Incoming Borrow Requests ({incomingRequests.length})</span>
                </h2>

                {incomingRequests.length === 0 ? (
                  <div className="bg-white rounded-2xl border border-slate-200 p-6 text-center text-sm text-slate-500">
                    No borrow requests on your listed books yet.
                  </div>
                ) : (
                  incomingRequests.map((req) => {
                    const borrower = students.find((s) => s.id === req.borrowerId) || students[0];
                    return (
                      <div key={req.id} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <span className="text-xs font-bold text-indigo-600">{req.courseCode}</span>
                            <h3 className="font-bold text-slate-900">{req.bookTitle}</h3>
                            <p className="text-xs text-slate-600">
                              Requested by <strong>{borrower.name}</strong> (★ {borrower.rating})
                            </p>
                          </div>
                          <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
                            {req.status}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-2">
                          {req.status === 'Pending' && (
                            <>
                              <button
                                onClick={() => handleApproveRequest(req)}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>Approve (Start 7-Day Loan)</span>
                              </button>
                              <button
                                onClick={() => handleRejectRequest(req)}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                <span>Decline</span>
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => setActiveChatRequest(req)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                            <span>Chat</span>
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              <div className="space-y-3">
                <h2 className="text-lg font-bold text-slate-900">My Listed Inventory ({myListedBooks.length})</h2>
                <div className="bg-white rounded-2xl border border-slate-200 divide-y divide-slate-100">
                  {myListedBooks.map((b) => (
                    <div key={b.id} className="p-3.5 flex items-center justify-between gap-3">
                      <div>
                        <span className="text-xs font-bold text-indigo-600 mr-2">{b.courseCode}</span>
                        <span className="text-sm font-semibold text-slate-900">{b.title}</span>
                      </div>
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700">
                        {b.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CAMPUS DEPARTMENT WISHLIST */}
        {activeTab === 'wishlist' && (
          <div className="max-w-2xl mx-auto bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center">
                <Heart className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-slate-900">Course Code Wishlist Alerts</h2>
                <p className="text-xs text-slate-500">
                  Get instant campus notifications whenever a peer lists a textbook matching your upcoming courses.
                </p>
              </div>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const val = e.target.courseInput.value.trim().toUpperCase();
                if (val && !wishlistCourses.includes(val)) {
                  setWishlistCourses((prev) => [...prev, val]);
                  pushNotification('info', 'Course Added to Wishlist', `Watching campus listings for ${val}.`);
                }
                e.target.reset();
              }}
              className="flex gap-2"
            >
              <input
                name="courseInput"
                placeholder="Enter course code (e.g. CS401, ME305)..."
                className="flex-1 px-3.5 py-2 text-sm border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-xl"
              >
                Watch Course
              </button>
            </form>

            <div className="flex flex-wrap gap-2">
              {wishlistCourses.map((code) => (
                <span
                  key={code}
                  className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-indigo-50 text-indigo-800 border border-indigo-200 text-xs font-bold"
                >
                  <Tag className="w-3.5 h-3.5" />
                  {code}
                  <button
                    onClick={() => setWishlistCourses((prev) => prev.filter((c) => c !== code))}
                    className="text-indigo-400 hover:text-indigo-700"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* MODAL: LIST A NEW TEXTBOOK (WITH ISBN LOOKUP & BARCODE SCANNER) */}
      {showListModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900">List a Textbook on OpenShelf</h3>
              <button onClick={() => setShowListModal(false)} className="text-slate-400 hover:text-slate-700 text-xl">
                ×
              </button>
            </div>

            <div className="flex flex-wrap gap-2 p-3 rounded-xl bg-slate-50 border border-slate-200">
              <input
                type="text"
                value={newBook.isbn}
                onChange={(e) => setNewBook({ ...newBook, isbn: e.target.value })}
                placeholder="ISBN-13 (e.g. 9780262033848)"
                className="flex-1 px-3 py-1.5 text-xs border border-slate-200 rounded-lg bg-white"
              />
              <button
                type="button"
                onClick={() => handleIsbnLookup()}
                disabled={isbnLoading}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-white text-xs font-semibold hover:bg-slate-900 inline-flex items-center gap-1"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {isbnLoading ? 'Fetching...' : 'Open Library Fill'}
              </button>
              <button
                type="button"
                onClick={simulateBarcodeScan}
                className="px-3 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 text-xs font-semibold hover:bg-indigo-100 inline-flex items-center gap-1"
              >
                <QrCode className="w-3.5 h-3.5" />
                {scannerSimulated ? 'Scanning...' : 'Scan Barcode'}
              </button>
            </div>

            <form onSubmit={handleCreateBook} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Book Title *</label>
                <input
                  required
                  value={newBook.title}
                  onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
                  placeholder="e.g. Operating System Concepts"
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Author(s)</label>
                  <input
                    value={newBook.author}
                    onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
                    placeholder="Silberschatz, Galvin"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Course Code *</label>
                  <input
                    required
                    value={newBook.courseCode}
                    onChange={(e) => setNewBook({ ...newBook, courseCode: e.target.value })}
                    placeholder="e.g. CS301"
                    className="w-full px-3 py-2 text-sm border border-slate-200 rounded-xl uppercase"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Department</label>
                  <select
                    value={newBook.department}
                    onChange={(e) => setNewBook({ ...newBook, department: e.target.value })}
                    className="w-full px-2.5 py-2 text-xs border border-slate-200 rounded-xl bg-white"
                  >
                    <option>Computer Science</option>
                    <option>Electrical Engineering</option>
                    <option>Mechanical Engineering</option>
                    <option>Mathematics & Data Science</option>
                    <option>Physics</option>
                    <option>Chemistry & Bio</option>
                    <option>Civil Engineering</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Edition</label>
                  <input
                    value={newBook.edition}
                    onChange={(e) => setNewBook({ ...newBook, edition: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Condition</label>
                  <select
                    value={newBook.condition}
                    onChange={(e) => setNewBook({ ...newBook, condition: e.target.value })}
                    className="w-full px-2.5 py-2 text-xs border border-slate-200 rounded-xl bg-white"
                  >
                    <option>Mint</option>
                    <option>Like New</option>
                    <option>Good</option>
                    <option>Fair</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowListModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-700 text-white"
                >
                  Publish Textbook
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: LENDER-BORROWER HANDOFF CHAT */}
      {activeChatRequest && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-xl border border-slate-200 flex flex-col max-h-[80vh]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-sm text-slate-900">Campus Handoff Chat</h3>
                <p className="text-xs text-slate-500">{activeChatRequest.bookTitle} ({activeChatRequest.courseCode})</p>
              </div>
              <button onClick={() => setActiveChatRequest(null)} className="text-slate-400 hover:text-slate-700 text-xl">
                ×
              </button>
            </div>

            <div className="flex-1 overflow-y-auto py-4 space-y-2.5">
              {activeChatRequest.messages.map((m) => {
                const isMe = m.senderId === currentUser.id;
                const sender = students.find((s) => s.id === m.senderId);
                return (
                  <div key={m.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                    <span className="text-[10px] text-slate-400 mb-0.5">
                      {isMe ? 'You' : sender?.name} · {m.time}
                    </span>
                    <div
                      className={`px-3 py-2 rounded-2xl text-xs max-w-[80%] ${
                        isMe ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-800'
                      }`}
                    >
                      {m.text}
                    </div>
                  </div>
                );
              })}
            </div>

            <form onSubmit={handleSendMessage} className="pt-3 border-t border-slate-100 flex gap-2">
              <input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Suggest pickup spot (e.g. Science Café, 4 PM)..."
                className="flex-1 px-3 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <button
                type="submit"
                className="p-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: PEER RELIABILITY RATING */}
      {ratingModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-200 text-center space-y-4">
            <h3 className="font-bold text-lg text-slate-900">Rate Your Peer Exchange</h3>
            <p className="text-xs text-slate-600">
              How smooth and punctual was your textbook exchange for <strong>{ratingModal.bookTitle}</strong>?
            </p>
            <div className="flex justify-center gap-2 py-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRatingScore(star)}
                  className="p-1 transition transform hover:scale-110"
                >
                  <Star
                    className={`w-7 h-7 ${
                      star <= ratingScore ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                    }`}
                  />
                </button>
              ))}
            </div>
            <button
              onClick={submitPeerRating}
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold"
            >
              Submit Rating
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
